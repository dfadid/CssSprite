(ns NewCssSprite.core-test
  (:use clojure.test
        NewCssSprite.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
# NewCssSprite

I'm an app. Or maybe I'm a library? I haven't decided yet. 

The choice is up to you!

## Usage

FIXME

## License

Copyright © 2013 FIXME

Distributed under the Eclipse Public License, the same as Clojure.
